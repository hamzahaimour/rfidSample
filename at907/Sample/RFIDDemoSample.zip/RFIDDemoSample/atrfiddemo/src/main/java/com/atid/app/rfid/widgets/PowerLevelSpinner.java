package com.atid.app.rfid.widgets;

public class PowerLevelSpinner {

}
