package com.hdhe.scantest;

/**
 * Created by Administrator on 2018/4/2.
 */

public class Barcode {
    public int sn ;
    public String barcode ;
    public int count ;
}
